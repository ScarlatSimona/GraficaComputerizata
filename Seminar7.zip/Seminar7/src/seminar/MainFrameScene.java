/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seminar;

import com.jogamp.common.nio.Buffers;
import com.jogamp.newt.Screen;
import com.jogamp.opengl.util.FPSAnimator;
import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.TextureIO;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.nio.DoubleBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import static javax.media.opengl.GL.GL_COLOR_BUFFER_BIT;
import static javax.media.opengl.GL.GL_DEPTH_BUFFER_BIT;
import static javax.media.opengl.GL.GL_DEPTH_TEST;
import static javax.media.opengl.GL.GL_LINEAR;
import static javax.media.opengl.GL.GL_TEXTURE_2D;
import static javax.media.opengl.GL.GL_TEXTURE_MIN_FILTER;
import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.awt.GLCanvas;
import static javax.media.opengl.fixedfunc.GLMatrixFunc.GL_PROJECTION;
import javax.media.opengl.glu.GLU;
import javax.media.opengl.glu.GLUquadric;
import javax.swing.JOptionPane;

/**
 *
 * @author titus
 */
public class MainFrameScene extends javax.swing.JFrame {

    private final GLCanvas canvas;

    private double fov, zMin, zMax;
    private double tx, ty, tz;
    private double cx, cy, cz;
    private double ux, uy;
    private final double coordonataAxa = 3;
    private int mx, my;
    private boolean startMotion;

    private GL2 gl;
    private GLU glu;

    private final Polyhedron p = new Polyhedron();
    private final Polyhedron piramida = new Polyhedron();

    private int[] coduriTexturi;

    private final double[][][] puncteControl = {
        {{0, 0, 0}, {10, 0, 0}, {20, 0, 0}},
        {{0, 0, -10}, {10, 5, -10}, {20, 0, -10}},
        {{0, 0, -20}, {10, 0, -20}, {20, 0, -20}}
    };
    private final double[][][] puncteControlTextura = {
        {{0, 0}, {1, 0}},
        {{0, 1}, {1, 1}}
    };

    private double[] pct;
    private int suprafata, suprafataTexturata;

    private GLUquadric cilindru, disc;

    // Declaratii picking-selectie
    private int xpos, ypos; // coordonate mouse
    private final int maxSelect = 100; // nr corpuri
    // bufer selectie
    private IntBuffer buf_selectie = Buffers.newDirectIntBuffer(400);
    private boolean picking;
    private final int AXE = 0;
    private final int CAMP = 1;
    private HashMap<Integer, Boolean> selector = new HashMap<>();

    /**
     * Creates new form MainFrameScene
     *
     * @param canvas
     */
    public MainFrameScene(GLCanvas canvas, FPSAnimator animator) {
        this.canvas = canvas;
        this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.setPreferredSize(setDimension());
        this.setCanvas();
        this.pack();
        canvas.addGLEventListener(new GLEventListener() {
            @Override
            public void init(GLAutoDrawable glad) {
                
                glInit(glad);
            }

            @Override
            public void dispose(GLAutoDrawable glad) {
                animator.stop();
            }

            @Override
            public void display(GLAutoDrawable glad) {
                glDisplay(glad);
            }

            @Override
            public void reshape(GLAutoDrawable glad, int i, int i1, int i2, int i3) {
                glReshape(glad, i, i1, i2, i3);
            }
        });
        canvas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                motion(e); //To change body of generated methods, choose Tools | Templates.
            }
        });
        canvas.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                key(e);
            }
        });
        canvas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dubluClick(e);
            }

        });
    }

    private void dubluClick(MouseEvent e) {
        if (e.getClickCount() == 2) {
            xpos = e.getX();
            ypos = e.getY();
            picking = true;
        }
    }

    private int[] creareTexturi(String[] fisiere) {
        int n = fisiere.length;
        int[] coduri = new int[n];
        try {
            for (int i = 0; i < n; i++) {
                Texture textura = TextureIO.newTexture(new File(fisiere[i]), true);
                coduri[i] = textura.getTextureObject(gl);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex);
        }
        return coduri;
    }

    private Dimension setDimension() {
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        return new Dimension(screen.width * 4 / 5, screen.height * 4 / 5);
    }

    void transform() {
        gl.glRotated(ux, 1, 0, 0);
        gl.glRotated(uy, 0, 1, 0);
        gl.glTranslated(tx, ty, tz);
    }

    private void motion(MouseEvent e) {
        int x = e.getX(), y = e.getY();
        if (!startMotion) {
            startMotion = true;
            mx = x;
            my = y;
        } else {
            if (mx < x) {
                uy += 1;
            } else if (mx > x) {
                uy -= 1;
            }
            if (my < y) {
                ux += 1;
            } else if (my > y) {
                ux -= 1;
            }
            mx = x;
            my = y;
        }
    }

    private void key(KeyEvent evt) {
        if (evt.isControlDown()) {
            switch (evt.getKeyCode()) {
                case KeyEvent.VK_RIGHT:
                    cx += 0.1;
                    break;
                case KeyEvent.VK_LEFT:
                    cx -= 0.1;
                    break;
                case KeyEvent.VK_UP:
                    cy += 0.1;
                    break;
                case KeyEvent.VK_DOWN:
                    cy -= 0.1;
                    break;
                case KeyEvent.VK_PAGE_DOWN:
                    cz -= 0.1;
                    break;
                case KeyEvent.VK_PAGE_UP:
                    cz += 0.1;
                    break;
            }
        } else {
            switch (evt.getKeyCode()) {
                case KeyEvent.VK_SPACE:
                    initParameters();
                    break;
                case KeyEvent.VK_RIGHT:
                    tx += 0.1;
                    break;
                case KeyEvent.VK_LEFT:
                    tx -= 0.1;
                    break;
                case KeyEvent.VK_UP:
                    ty += 0.1;
                    break;
                case KeyEvent.VK_DOWN:
                    ty -= 0.1;
                    break;
                case KeyEvent.VK_PAGE_DOWN:
                    tz -= 0.1;
                    break;
                case KeyEvent.VK_PAGE_UP:
                    tz += 0.1;
                    break;
            }
        }
    }

    private void glReshape(GLAutoDrawable glad, int x, int y, int w, int h) {
        double asp = (double) w / h;
        gl.glViewport(x, y, w, h);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(fov, asp, zMin, zMax);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
    }

    private void glDisplay(GLAutoDrawable glad) {
        
       
        
        gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
      
       
      gl.glClearColor (0.8f,0.8f,0.8f,1.0f);
     
       
       gl.glLoadIdentity();
       
        
        glu.gluLookAt(cx, cy, cz, 0, 0, 0, 0, 1, 0);
        transform();
        desen(GL2.GL_RENDER);
    }

    private void desen(int mod) {
        if (picking) {
            picking = false;
            int k = procesareSelectie();
            for (int i = 0; i < k; i++) {
                int j = buf_selectie.get(i * 4 + 3);
                selector.replace(j, !selector.get(j));
            }
        }
        if (mod == GL2.GL_SELECT) {
            gl.glLoadName(AXE);
        }
        if (!selector.get(AXE)) {
            axis();
        }
        //gl.glCallList(suprafata);
        //if (mod == GL2.GL_SELECT) {
           // gl.glLoadName(CAMP);
       // }
        //if (!selector.get(CAMP)) {
           // gl.glCallList(suprafataTexturata);
        //} else {
            //gl.glCallList(suprafata);
       // }
        //Desenare casa
        gl.glPushMatrix();
        gl.glTranslated(5, 1, -5);
        //desenareCasa();
        gl.glPopMatrix();
        gl.glFlush();
        //Desenare fundatie
        desenareCilindru();
        desenareCilindru2();
        desenareCilindru3();
        //desenareCilindru4();
        desenareHeat();
        

        
    }

    private void desenareCasa() {
        /*p.draw(gl);
        gl.glPushMatrix();
        gl.glTranslated(-0.25, 2, -0.25);
        piramida.draw(gl);
        gl.glPopMatrix();
        */
    }

    private void glInit(GLAutoDrawable glad) {
        canvas.requestFocus();
        gl = canvas.getContext().getGL().getGL2();
        glu = GLU.createGLU();
        gl.glEnable(GL2.GL_DEPTH_TEST);
        lighting();
        coduriTexturi = creareTexturi(new String[]{
            "wall.jpg", "roof.jpg", "grass.jpg", "fundatie.jpg","heat.jpg"
        });
        initParameters();
        initGeometry();
        pct = liniarizare(puncteControl);
       //suprafata = gl.glGenLists(1);
      //  if (suprafata != 0) {
          // gl.glNewList(suprafata, GL2.GL_COMPILE);
          // creareSuprafata();
          // gl.glEndList();
       // }
        suprafataTexturata = gl.glGenLists(1);
        if (suprafataTexturata != 0) {
            gl.glNewList(suprafataTexturata, GL2.GL_COMPILE);
            creareSuprafataCuTexturare();
            gl.glEndList();
        }
        cilindru = glu.gluNewQuadric();
        disc = glu.gluNewQuadric();
        selector.put(AXE, false);
        selector.put(CAMP, false);
    }
    
    
     private void desenareCilindru() {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_AMBIENT_AND_DIFFUSE, FloatBuffer.wrap(new float[]{1.0f, 1.0f, 1.0f}));

        gl.glPushMatrix();

        gl.glTranslated(0, 0, -2);
        gl.glRotated(-90, 1, 0, 0);

        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, coduriTexturi[2]);
        glu.gluQuadricTexture(cilindru, true);
        //glu.gluCylinder(cilindru, 2, 2, 3, 30, 30);
        glu.gluSphere(disc, 1, 10, 10);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPushMatrix();
        gl.glTranslated(0, 0, 1);
        //glu.gluDisk(disc, 2, 0, 30, 30);
        gl.glPopMatrix();

        gl.glPopMatrix();
        gl.glDisable(GL2.GL_LIGHTING);
        gl.glDisable(GL2.GL_TEXTURE_2D);
    }
    
    private void desenareHeat() {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DISCRETE_AMD, FloatBuffer.wrap(new float[]{0.8f, 0.8f, 0.8f}));

        gl.glPushMatrix();

        gl.glTranslated(0, 0, 0);
        gl.glRotated(-30, 1, 0, 0);

        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, coduriTexturi[4]);
        glu.gluQuadricTexture(cilindru, true);
        // glu.gluDisk(disc, 1, 0, 8, 8);
        glu.gluCylinder(cilindru, 0.5, 0.5, 1, 5, 5);
        //glu.gluSphere(disc, 1, 10, 10);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPushMatrix();
        //gl.glTranslated(0, 0, 1);
       
        gl.glPopMatrix();

        gl.glPopMatrix();
        gl.glDisable(GL2.GL_LIGHTING);
        gl.glDisable(GL2.GL_TEXTURE_2D);
    }
    
    
    private void desenareCilindru2() {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DIFFUSE, FloatBuffer.wrap(new float[]{1.0f, 1.0f, 1.0f}));

        gl.glPushMatrix();

        gl.glTranslated(0, 0, -1);
        gl.glRotated(-90, 1, 0, 0);

        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, coduriTexturi[2]);
        glu.gluQuadricTexture(cilindru, true);
        //glu.gluCylinder(cilindru, 2, 2, 3, 30, 30);
        glu.gluSphere(disc, 0.8, 9, 9);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPushMatrix();
        gl.glTranslated(0, 0, 1);
        //glu.gluDisk(disc, 2, 0, 30, 30);
        gl.glPopMatrix();

        gl.glPopMatrix();
        gl.glDisable(GL2.GL_LIGHTING);
        gl.glDisable(GL2.GL_TEXTURE_2D);
    }
    
    private void desenareCilindru3() {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DIFFUSE, FloatBuffer.wrap(new float[]{1.0f, 1.0f, 1.0f}));

        gl.glPushMatrix();

        gl.glTranslated(0, 0, 0);
        gl.glRotated(-90, 1, 0, 0);

        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, coduriTexturi[2]);
        glu.gluQuadricTexture(cilindru, true);
        //glu.gluCylinder(cilindru, 2, 2, 3, 30, 30);
        glu.gluSphere(disc, 0.5, 8, 8);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPushMatrix();
        gl.glTranslated(0, 0, 1);
        //glu.gluDisk(disc, 2, 0, 30, 30);
        gl.glPopMatrix();

        gl.glPopMatrix();
        gl.glDisable(GL2.GL_LIGHTING);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        
        gl.glPushMatrix();
 gl.glColor3f(0.0f,0.0f,0.0f);
 gl.glTranslated(-0.1, -0.4, 0.3);
 
 glu.gluSphere(disc,0.04f,10,10);
 
 gl.glTranslated(0.2, -0.0, 0.02);
  glu.gluSphere(disc,0.04f,10,10);
  
  gl.glColor3f(1.0f, 0.5f , 0.0f);
  gl.glTranslated(-0.1, -0.1, -0.25);
  gl.glRotated(85, 1, 0, 0);
  glu.gluCylinder(cilindru, 0.1, 0, 0.2, 10, 10);
 gl.glPopMatrix();
 
 
 //gl.glColor3f(1.0f, 0.5f , 0.5f);
  //gl.glTranslated(4, 0, 0.3);
 //gl.glRotatef(0.0f,1.0f, 0.0f, 0.0f);
 //glu.gluCylinder(cilindru, 0.2, 0, 0.2, 10, 10);
 
        //desenareCilindru4();
        
        
    }

    private void desenareCilindru4() {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DIFFUSE, FloatBuffer.wrap(new float[]{0.0f, 0.0f, 0.0f}));

        gl.glPushMatrix();

        gl.glTranslated(0, 0, -2);
        gl.glRotated(-50, 1, 0, 0);

        //gl.glEnable(GL2.GL_TEXTURE_2D);
        //gl.glBindTexture(GL2.GL_TEXTURE_2D, coduriTexturi[2]);
        glu.gluQuadricTexture(cilindru, true);
        //glu.gluCylinder(cilindru, 2, 2, 3, 30, 30);
        glu.gluSphere(disc, 0.2, 4, 4);
        //gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPushMatrix();
        gl.glTranslated(0, 0, 1);
        //glu.gluDisk(disc, 2, 0, 30, 30);
        gl.glPopMatrix();

        gl.glPopMatrix();
        gl.glDisable(GL2.GL_LIGHTING);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        
        
    }

    private void creareSuprafata() {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DIFFUSE, FloatBuffer.wrap(new float[]{0, 1, 0}));
        gl.glEnable(GL2.GL_MAP2_VERTEX_3);
        gl.glMap2d(GL2.GL_MAP2_VERTEX_3, 0, 1, 3, 3, 0, 1, 9, 3, DoubleBuffer.wrap(pct));
        gl.glMapGrid2d(20, 0, 1, 20, 0, 1);
        gl.glEvalMesh2(GL2.GL_FILL, 0, 20, 0, 20);
        gl.glDisable(GL2.GL_LIGHTING);
    }

    private void creareSuprafataCuTexturare() {
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glEnable(GL2.GL_MAP2_TEXTURE_COORD_2);
        gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_DECAL);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, coduriTexturi[2]);
        gl.glEnable(GL2.GL_MAP2_VERTEX_3);
        gl.glMap2d(GL2.GL_MAP2_VERTEX_3, 0, 1, 3, 3, 0, 1, 9, 3, DoubleBuffer.wrap(pct));
        gl.glMapGrid2d(20, 0, 1, 20, 0, 1);
        gl.glMap2d(GL2.GL_MAP2_TEXTURE_COORD_2, 0, 1, 2, 2, 0, 1, 4, 2,
                DoubleBuffer.wrap(liniarizare(puncteControlTextura)));
        gl.glEvalMesh2(GL2.GL_FILL, 0, 20, 0, 20);
        gl.glDisable(GL2.GL_TEXTURE_2D);
    }

    private double[] liniarizare(double[][][] x) {
        int n = x.length, m = x[0].length;
        int r = x[0][0].length;
        double[] p = new double[n * m * r];
        for (int i = 0, k = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                for (int l = 0; l < r; l++, k++) {
                    p[k] = x[i][j][l];
                }
            }
        }
        return p;
    }

    private void lighting() {
        gl.glEnable(GL2.GL_AUTO_NORMAL);
        gl.glEnable(GL2.GL_LIGHT0);
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, FloatBuffer.wrap(new float[]{0, 0, 5, 0}));
    }

    private void initGeometry() {
        //p.setLighting(true);
        p.setTexturare(true);
        p.setCodTextura(coduriTexturi[0]);
        p.setCoordonateTexturareT(new double[]{0, 1, 1, 0});
        p.setCoordonateTexturareS(new double[]{0, 0, 1, 1});
        p.setColor(new float[]{0, 1, 1});
        p.addVertex(new double[]{0, 0, 0});
        p.addVertex(new double[]{2, 0, 0});
        p.addVertex(new double[]{2, 0, 2});
        p.addVertex(new double[]{0, 0, 2});
        p.addVertex(new double[]{0, 2, 0});
        p.addVertex(new double[]{2, 2, 0});
        p.addVertex(new double[]{2, 2, 2});
        p.addVertex(new double[]{0, 2, 2});
        p.addSurface(new int[]{0, 1, 2, 3});
        p.addSurface(new int[]{2, 6, 7, 3});
        p.addSurface(new int[]{1, 5, 6, 2});
        p.addSurface(new int[]{3, 7, 4, 0});
        p.addSurface(new int[]{0, 4, 5, 1});
        p.addSurface(new int[]{6, 5, 4, 7});
        piramida.setCodTextura(coduriTexturi[1]);
        piramida.setTexturare(true);
        piramida.setCoordonateTexturareT(new double[]{0, 1, 0.5});
        piramida.setCoordonateTexturareS(new double[]{0, 0, 1});
        piramida.addVertex(new double[]{0, 0, 0});
        piramida.addVertex(new double[]{2.5, 0, 0});
        piramida.addVertex(new double[]{2.5, 0, 2.5});
        piramida.addVertex(new double[]{0, 0, 2.5});
        piramida.addVertex(new double[]{1.25, 2, 1.25});
        //piramida.addSurface(new int[]{0, 1, 2, 3});
        piramida.addSurface(new int[]{2, 4, 3});
        piramida.addSurface(new int[]{1, 4, 2});
        piramida.addSurface(new int[]{0, 4, 1});
        piramida.addSurface(new int[]{3, 4, 0});
        piramida.setColor(new float[]{1, 0, 0});
        piramida.setLighting(true);
    }

    private void initParameters() {
        fov = 75;
        zMin = 2;
        zMax = 20;
        tx = ty = tz = ux = uy = 0;
        cx = cy = 0;
        cz = 5;
        selector.keySet().forEach(K -> {
            selector.replace(K, false);
        });
    }

    private void setCanvas() {
        this.getContentPane().add(canvas, BorderLayout.CENTER);
    }

    void axis() {
        gl.glBegin(GL2.GL_LINES);
        gl.glColor3d(1, 0, 0);
        gl.glVertex3d(-coordonataAxa, 0, 0);
        gl.glVertex3d(coordonataAxa, 0, 0);
        gl.glColor3d(0, 1, 0);
        gl.glVertex3d(0, -coordonataAxa, 0);
        gl.glVertex3d(0, coordonataAxa, 0);
        gl.glColor3d(0, 0, 1);
        gl.glVertex3d(0, 0, -coordonataAxa);
        gl.glVertex3d(0, 0, coordonataAxa);
        gl.glEnd();
    }

    private int procesareSelectie() {
        int hits; // variabila in care intorc numarul de primitive selectate 
// stabilire bufer de selectie si numar maxim de primitive ce pot fi selectate
        gl.glSelectBuffer(maxSelect, buf_selectie); // trecere in mod select
        gl.glRenderMode(GL2.GL_SELECT);
// creare si initializare stiva de selectie
        gl.glInitNames();
        gl.glPushName(0); // preluare viewport curent 
        int[] viewport = new int[4];
        gl.glGetIntegerv(GL2.GL_VIEWPORT, viewport, 0);
        int w = viewport[2], h = viewport[3];
        double aspectRatio = (double) w / h;
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glPushMatrix(); //salvare matrice de proiectie
        gl.glLoadIdentity(); // stabilire volum de selectie 
        glu.gluPickMatrix((double) xpos, (double) (h - ypos), 4.0, 4.0, viewport, 0);
        glu.gluPerspective(fov, aspectRatio, 0, zMax);
// trasare in mod selectie
        gl.glMatrixMode(GL2.GL_MODELVIEW);
        desen(GL2.GL_SELECT);
// determinarea numarului de primitive intersectate de volumul de selectie 
// (primitive selectate)
        hits = gl.glRenderMode(GL2.GL_RENDER);
// restaurare matrice de proiectie 
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glPopMatrix();
        gl.glMatrixMode(GL2.GL_MODELVIEW);
        desen(GL2.GL_RENDER);
        if (hits <= 0) {
            return -1;
        } else {
            return hits;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        GLCanvas canvas = new GLCanvas();
        FPSAnimator animator = new FPSAnimator(canvas, 60);
        animator.start();
        MainFrameScene scene = new MainFrameScene(canvas, animator);
        scene.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
