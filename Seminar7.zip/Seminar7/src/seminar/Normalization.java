/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seminar;

/**
 *
 * @author titus
 */
public interface Normalization {

    default double[] normala(double p1[], double p2[], double p3[]) {
        double[] n = new double[3];
        double vx = p2[0] - p1[0], vy = p2[1] - p1[1], vz = p2[2] - p1[2];
        double wx = p3[0] - p1[0], wy = p3[1] - p1[1], wz = p3[2] - p1[2];
        n[0] = vy * wz - wy * vz;
        n[1] = wx * vz - vx * wz;
        n[2] = vx * wy - wx * vy;
        return normalizare(n);
    }

    default double[] normalizare(double[] v) {
        double s = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        v[0] /= s;
        v[1] /= s;
        v[2] /= s;
        return v;
    }
}
