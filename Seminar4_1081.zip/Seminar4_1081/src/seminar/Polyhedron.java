/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seminar;

import java.nio.FloatBuffer;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.media.opengl.GL2;

/**
 *
 * @author titus
 */
public class Polyhedron implements Normalization {
    private double[][] v;
    private int[][] s;
    private final Set<double[]> sv=new LinkedHashSet<>();
    private final Set<int[]> ss = new LinkedHashSet<>();
    
    private boolean lighting;
    private FloatBuffer color = FloatBuffer.wrap(new float[]{1,1,1});
    
    public void addVertex(double[] vertex){
        sv.add(vertex);
        double[][] t = new double[sv.size()][];
        v = sv.toArray(t);
    }
    
    public void addSurface(int[] surface){
        ss.add(surface);
        int[][] t = new int[ss.size()][];
        s = ss.toArray(t);
    }
    
    public void draw(GL2 gl){
        if(lighting){
            gl.glEnable(GL2.GL_LIGHTING);
            gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DIFFUSE, color);
        } else{
            gl.glColor3fv(color);
        }
        for (int[] surface : s) {
            gl.glBegin(GL2.GL_POLYGON);
            for (int j = 0; j < surface.length; j++) {
                int n = surface.length;
                gl.glNormal3dv(normala(v[surface[j]], v[surface[(j+1)%n]], v[surface[(j+2)%n]]), 0);
                gl.glVertex3d(v[surface[j]][0], v[surface[j]][1], v[surface[j]][2]);
            }
            gl.glEnd();
        }
        if(lighting){
            gl.glDisable(GL2.GL_LIGHTING);
        }
    }
    
    public void setColor(float[] c){
        color = FloatBuffer.wrap(c);
    }

    public boolean isLighting() {
        return lighting;
    }

    public void setLighting(boolean lighting) {
        this.lighting = lighting;
    }
    
}
