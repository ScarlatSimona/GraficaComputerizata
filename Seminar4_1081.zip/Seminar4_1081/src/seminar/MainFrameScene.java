/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seminar;

import com.jogamp.opengl.util.FPSAnimator;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.nio.FloatBuffer;
import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.awt.GLCanvas;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author titus
 */
public class MainFrameScene extends javax.swing.JFrame {

    private final GLCanvas canvas;

    private double fov, zMin, zMax;
    private double tx, ty, tz;
    private double cx, cy, cz;
    private double ux, uy;
    private final double coordonataAxa = 3;
    private int mx, my;
    private boolean startMotion;

    private GL2 gl;
    private GLU glu;

    private Polyhedron p = new Polyhedron();

    /**
     * Creates new form MainFrameScene
     *
     * @param canvas
     */
    public MainFrameScene(GLCanvas canvas, FPSAnimator animator) {
        this.canvas = canvas;
        this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.setPreferredSize(setDimension());
        this.setCanvas();
        this.pack();
        canvas.addGLEventListener(new GLEventListener() {
            @Override
            public void init(GLAutoDrawable glad) {
                glInit(glad);
            }

            @Override
            public void dispose(GLAutoDrawable glad) {
                animator.stop();
            }

            @Override
            public void display(GLAutoDrawable glad) {
                glDisplay(glad);
            }

            @Override
            public void reshape(GLAutoDrawable glad, int i, int i1, int i2, int i3) {
                glReshape(glad, i, i1, i2, i3);
            }
        });
        canvas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                motion(e); //To change body of generated methods, choose Tools | Templates.
            }
        });
        canvas.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                key(e);
            }
        });
    }

    private Dimension setDimension() {
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        return new Dimension(screen.width * 4 / 5, screen.height * 4 / 5);
    }

    void transform() {
        gl.glRotated(ux, 1, 0, 0);
        gl.glRotated(uy, 0, 1, 0);
        gl.glTranslated(tx, ty, tz);
    }

    private void motion(MouseEvent e) {
        int x = e.getX(), y = e.getY();
        if (!startMotion) {
            startMotion = true;
            mx = x;
            my = y;
        } else {
            if (mx < x) {
                uy += 1;
            } else if (mx > x) {
                uy -= 1;
            }
            if (my < y) {
                ux += 1;
            } else if (my > y) {
                ux -= 1;
            }
            mx = x;
            my = y;
        }
    }

    private void key(KeyEvent evt) {
        if (evt.isControlDown()) {
            switch (evt.getKeyCode()) {
                case KeyEvent.VK_RIGHT:
                    cx += 0.1;
                    break;
                case KeyEvent.VK_LEFT:
                    cx -= 0.1;
                    break;
                case KeyEvent.VK_UP:
                    cy += 0.1;
                    break;
                case KeyEvent.VK_DOWN:
                    cy -= 0.1;
                    break;
                case KeyEvent.VK_PAGE_DOWN:
                    cz -= 0.1;
                    break;
                case KeyEvent.VK_PAGE_UP:
                    cz += 0.1;
                    break;
            }
        } else {
            switch (evt.getKeyCode()) {
                case KeyEvent.VK_SPACE:
                    initParameters();
                    break;
                case KeyEvent.VK_RIGHT:
                    tx += 0.1;
                    break;
                case KeyEvent.VK_LEFT:
                    tx -= 0.1;
                    break;
                case KeyEvent.VK_UP:
                    ty += 0.1;
                    break;
                case KeyEvent.VK_DOWN:
                    ty -= 0.1;
                    break;
                case KeyEvent.VK_PAGE_DOWN:
                    tz -= 0.1;
                    break;
                case KeyEvent.VK_PAGE_UP:
                    tz += 0.1;
                    break;
            }
        }
    }

    private void glReshape(GLAutoDrawable glad, int x, int y, int w, int h) {
        double asp = (double) w / h;
        gl.glViewport(x, y, w, h);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(fov, asp, zMin, zMax);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
    }

    private void glDisplay(GLAutoDrawable glad) {
        gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
        gl.glLoadIdentity();
        glu.gluLookAt(cx, cy, cz, 0, 0, 0, 0, 1, 0);
        transform();
        axis();
        p.draw(gl);
        gl.glFlush();
    }

    private void glInit(GLAutoDrawable glad) {
        canvas.requestFocus();
        initParameters();
        initGeometry();
        gl = canvas.getContext().getGL().getGL2();
        glu = GLU.createGLU();
        gl.glEnable(GL2.GL_DEPTH_TEST);
        lighting();
    }

    private void lighting(){
        gl.glEnable(GL2.GL_LIGHT0);
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, FloatBuffer.wrap(new float[]{0,0,5,0}));
    }
    
    private void initGeometry() {
        p.setLighting(true);
        p.setColor(new float[]{0, 1, 1});
        p.addVertex(new double[]{0, 0, 0});
        p.addVertex(new double[]{2, 0, 0});
        p.addVertex(new double[]{2, 0, 2});
        p.addVertex(new double[]{0, 0, 2});
        p.addVertex(new double[]{0, 2, 0});
        p.addVertex(new double[]{2, 2, 0});
        p.addVertex(new double[]{2, 2, 2});
        p.addVertex(new double[]{0, 2, 2});
        p.addSurface(new int[]{0, 1, 2, 3});
        p.addSurface(new int[]{2, 6, 7, 3});
        p.addSurface(new int[]{1, 5, 6, 2});
        p.addSurface(new int[]{3, 7, 4, 0});
        p.addSurface(new int[]{0, 4, 5, 1});
        p.addSurface(new int[]{6, 5, 4, 7});
    }

    private void initParameters() {
        fov = 70;
        zMin = 2;
        zMax = 20;
        tx = ty = tz = ux = uy = 0;
        cx = cy = 0;
        cz = 5;
    }

    private void setCanvas() {
        this.getContentPane().add(canvas, BorderLayout.CENTER);
    }

    void axis() {
        gl.glBegin(GL2.GL_LINES);
        gl.glColor3d(1, 0, 0);
        gl.glVertex3d(-coordonataAxa, 0, 0);
        gl.glVertex3d(coordonataAxa, 0, 0);
        gl.glColor3d(0, 1, 0);
        gl.glVertex3d(0, -coordonataAxa, 0);
        gl.glVertex3d(0, coordonataAxa, 0);
        gl.glColor3d(0, 0, 1);
        gl.glVertex3d(0, 0, -coordonataAxa);
        gl.glVertex3d(0, 0, coordonataAxa);
        gl.glEnd();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        GLCanvas canvas = new GLCanvas();
        FPSAnimator animator = new FPSAnimator(canvas, 60);
        animator.start();
        MainFrameScene scene = new MainFrameScene(canvas, animator);
        scene.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
