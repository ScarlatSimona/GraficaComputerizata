/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sub1examen;

import java.util.ArrayList;
import javafx.scene.chart.Axis;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author simonascarlat
 */
public class Line extends LineChart{
    
    public Line(ArrayList<DataToDisplay> listaDate) {
        super(new NumberAxis(), new NumberAxis());
        
        XYChart.Series<Number,Number> serie = new XYChart.Series<>();
        for(int i=0;i< listaDate.size();i++)
        {
            XYChart.Data<Number,Number> data = new XYChart.Data<>(listaDate.get(i).nrLuni,listaDate.get(i).volumVanzari);
            Rectangle formaPunct = new Rectangle(10,10);
            formaPunct.setFill(Color.BLUE);
            data.setNode(formaPunct);
            serie.getData().add(data);
        }
        this.getData().add(serie);
    }
    
}
