/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sub1examen;



import java.util.ArrayList;
import javafx.scene.chart.Axis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author simonascarlat
 */
public class Scatterplot extends ScatterChart<Number, Number>{
    
    
    public Scatterplot(ArrayList<DataToDisplay> lista) {
        super(new NumberAxis(), new NumberAxis());
        
        
        XYChart.Series<Number,Number> serie = new XYChart.Series<>();
        for(int i = 0; i<lista.size(); i++)
        {
            XYChart.Data<Number,Number> data = new XYChart.Data<>(lista.get(i).nrLuni,lista.get(i).volumVanzari);
            Rectangle formaPunct = new Rectangle(10,10);
            formaPunct.setFill(Color.RED);
            data.setNode(formaPunct);
            serie.getData().add(data);
        }
        this.getData().add(serie);
    }
    
}
