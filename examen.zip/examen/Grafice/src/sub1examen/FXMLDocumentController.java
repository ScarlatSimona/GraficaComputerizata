/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sub1examen;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.chart.BubbleChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 *
 * @author simonascarlat
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Button btn_pie;
    
    @FXML
    private Button btn_scatter;
     
    @FXML
    private Button btn_bar;
      
    @FXML
    private Button btn_line;
    
    @FXML
    private Button btn_area;
    
    @FXML
    private Button btn_bubble;
    
    private Stage myStage;
    
    private ArrayList<DataToDisplay> listaDate=new ArrayList<>();
    
    
    private void readFromFile() throws FileNotFoundException, IOException
    {
        BufferedReader br = new BufferedReader(new FileReader("line.txt"));
        
        String linie = br.readLine();
        try
        {
            while(linie != null)
            {
                String[] elem = new String[3];
                elem = linie.split(" ");
                listaDate.add(new DataToDisplay(Double.parseDouble(elem[0]), Double.parseDouble(elem[1]), elem[2]));
                linie = br.readLine();
            }
        }catch(Exception ex)
        {
            ex.printStackTrace();
        }finally
        {
            br.close();
        }
            
            
    }
   
    @FXML
    private void drawScatterChart(ActionEvent event) {
        
       Scene scene = myStage.getScene();
       BorderPane root = (BorderPane)scene.getRoot();
       root.setCenter(new Scatterplot(listaDate));
    }
    
    
     @FXML
    private void drawLine(ActionEvent event) {
        Scene scene = myStage.getScene();
        BorderPane root = (BorderPane) scene.getRoot();
        root.setCenter(new Line(listaDate));
    }
    
    
    @FXML
    private void drawArea(ActionEvent event) {
        Scene scene = myStage.getScene();
        BorderPane root = (BorderPane)scene.getRoot();
        root.setCenter(new AreaPlot(listaDate));
    }
    
    @FXML
    private void drawBubble(ActionEvent event) {
        Scene scene = myStage.getScene();
        BorderPane root = (BorderPane) scene.getRoot();
        root.setCenter(new BubblePlot(listaDate));
    }
    
    @FXML
    private void drawBar(ActionEvent event) {
        
        Scene scene = myStage.getScene();
        BorderPane root = (BorderPane) scene.getRoot();
        root.setCenter(new BarPlot(listaDate));
        
    }
    
     @FXML
    private void drawPieChart(ActionEvent event) {
        Scene scene = myStage.getScene();
        BorderPane root = (BorderPane) scene.getRoot();
        root.setCenter(new PiePlot(listaDate));
    }
    
     void setMyStage(Stage stage) {
        this.myStage = stage;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            readFromFile();
            System.out.println(listaDate.get(2).luna);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

   
    
}
