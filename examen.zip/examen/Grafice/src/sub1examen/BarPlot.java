/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sub1examen;

import java.util.ArrayList;
import javafx.scene.chart.Axis;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author simonascarlat
 */
public class BarPlot extends BarChart<String, Number>{
    
    public BarPlot(ArrayList<DataToDisplay> listaDate) {
        super(new CategoryAxis(), new NumberAxis());
        
        XYChart.Series<String,Number> serie = new XYChart.Series<>();
        for(int i=0;i< listaDate.size();i++)
        {
            XYChart.Data<String,Number> data = new XYChart.Data<>(listaDate.get(i).luna, listaDate.get(i).volumVanzari);
            serie.getData().add(data);
           
        }
        this.getData().add(serie);
    }
    
}
