/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sub1examen;

/**
 *
 * @author simonascarlat
 */
public class DataToDisplay {
    
    public double nrLuni;
    public double volumVanzari;
    public String luna;
    
    public DataToDisplay(double nrLuni, double volumVanzari, String luna)
    {
        this.nrLuni = nrLuni;
        this.volumVanzari = volumVanzari;
        this.luna = luna;
    }
    
}
