/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sub1examen;

import java.util.ArrayList;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.Axis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

/**
 *
 * @author simonascarlat
 */
public class AreaPlot extends AreaChart<Number, Number>{
    
    public AreaPlot(ArrayList<DataToDisplay> listaDate) {
        super(new NumberAxis(), new NumberAxis());
        
        XYChart.Series<Number,Number> serie = new XYChart.Series<>();
        for(int i = 0;i <listaDate.size();i++)
        {
            XYChart.Data<Number,Number> date = new XYChart.Data<>(listaDate.get(i).nrLuni,listaDate.get(i).volumVanzari);
            serie.getData().add(date);
        }
        this.getData().add(serie);
    }
    
}
