/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sub1examen;

import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;

/**
 *
 * @author simonascarlat
 */
public class PiePlot extends PieChart{
    
    public PiePlot(ArrayList<DataToDisplay> listaDate)
    {
        super();
        ObservableList<PieChart.Data> serie = FXCollections.observableArrayList();
        for(int i=0;i< listaDate.size();i++)
        {
            serie.add(new PieChart.Data(listaDate.get(i).luna, listaDate.get(i).volumVanzari));
        }
        this.setData(serie);
    }
    
}
