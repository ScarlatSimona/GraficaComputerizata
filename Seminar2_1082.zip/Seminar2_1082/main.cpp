/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: stud
 *
 * Created on March 9, 2017, 6:22 PM
 */

#include <cstdlib>
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <glut.h>

using namespace std;

double cx, cy, cz, zNear, zFar, fovy;
double ux, uy;
int mx, my;
double tx, ty, tz;
boolean startMotion = false;

double coordonataAxa = 5;

void initializareParametrii() {
    cx = cy = 0;
    cz = 5;
    zNear = 2;
    zFar = 20;
    fovy = 70;
    ux = uy = 0;
    tx = ty = tz = 0;
}

void transformareScena() {
    glRotated(ux, 1, 0, 0);
    glRotated(uy, 0, 1, 0);
    glTranslated(tx, ty, tz);
}

void motion(int x, int y) {
    if (!startMotion) {
        startMotion = true;
        mx = x;
        my = y;
    } else {
        if (mx < x) {
            uy += 1;
        } else {
            if (mx > x) {
                uy -= 1;
            }
        }
        if (my < y) {
            ux += 1;
        } else {
            if (my > y) {
                ux -= 1;
            }
        }
        mx = x;
        my = y;
        glutPostRedisplay();
    }
}

void desen() {
    glBegin(GL_LINES);
    glColor3d(1, 0, 0);
    glVertex3d(-coordonataAxa, 0, 0);
    glVertex3d(coordonataAxa, 0, 0);
    glColor3d(0, 1, 0);
    glVertex3d(0, -coordonataAxa, 0);
    glVertex3d(0, coordonataAxa, 0);
    glColor3d(0, 0, 1);
    glVertex3d(0, 0, -coordonataAxa);
    glVertex3d(0, 0, coordonataAxa);
    glEnd();
}

void desenare() {
    // Stergere in buferul de culoare si in buferul de adancime
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // initializare matrice de modelare cu matricea identitate    
    glLoadIdentity();
    // Plasarea camerei in scena
    gluLookAt(cx, cy, cz, 0, 0, 0, 0, 1, 0);
    // desenare scena
    transformareScena();
    desen();
    glFlush();
    glutSwapBuffers();
}

void redesenare(int w, int h) {
    // Calcul aspect-ratio
    double a = (double) w / h;
    glViewport(0, 0, w, h);
    // Activare matrice de proiectie
    glMatrixMode(GL_PROJECTION);
    // Initializare matrice de proiectie
    glLoadIdentity();
    // Proiectie
    gluPerspective(fovy, a, zNear, zFar);
    // Reactivare matrice de modelare
    glMatrixMode(GL_MODELVIEW);
}

void tratareTasteSpeciale(int k, int x, int y) {
    int modif = glutGetModifiers();
    if (modif == GLUT_ACTIVE_CTRL) {
        switch (k) {
            case GLUT_KEY_UP:
                cy += 0.1;
                break;
            case GLUT_KEY_DOWN:
                cy -= 0.1;
                break;
            case GLUT_KEY_LEFT:
                cx -= 0.1;
                break;
            case GLUT_KEY_RIGHT:
                cx += 0.1;
                break;
            case GLUT_KEY_PAGE_DOWN:
                cz -= 0.1;
                break;
            case GLUT_KEY_PAGE_UP:
                cz += 0.1;
                break;
        }
    } else {
        switch (k) {
            case GLUT_KEY_UP:
                ty += 0.1;
                break;
            case GLUT_KEY_DOWN:
                ty -= 0.1;
                break;
            case GLUT_KEY_LEFT:
                tx -= 0.1;
                break;
            case GLUT_KEY_RIGHT:
                tx += 0.1;
                break;
            case GLUT_KEY_PAGE_DOWN:
                tz -= 0.1;
                break;
            case GLUT_KEY_PAGE_UP:
                tz += 0.1;
                break;
        }

    }
    glutPostRedisplay();
}

void tratareTaste(unsigned char k, int x, int y) {
    switch (k) {
        case ' ':
            initializareParametrii();
            break;
    }
    glutPostRedisplay();
}

/*
 * 
 */
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(700, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Exemplu Seminar 1");
    initializareParametrii();
    glutDisplayFunc(desenare);
    glutReshapeFunc(redesenare);
    glutMotionFunc(motion);
    glutSpecialFunc(tratareTasteSpeciale);
    glutKeyboardFunc(tratareTaste);
    glutMainLoop();
    return 0;
}

