/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seminar.seminar3.g1081;

import com.jogamp.opengl.util.FPSAnimator;
import com.jogamp.opengl.util.gl2.GLUT;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import static javax.media.opengl.GL.GL_COLOR_BUFFER_BIT;
import static javax.media.opengl.GL.GL_DEPTH_BUFFER_BIT;
import static javax.media.opengl.GL.GL_TRIANGLES;
import javax.media.opengl.GL2;
import static javax.media.opengl.GL2GL3.GL_QUADS;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.awt.GLCanvas;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author titus
 */
public class MainFrameScene extends javax.swing.JFrame {

    private final GLCanvas canvas;
    GLUT glut = new GLUT();

    private double fov, zMin, zMax;
    private double tx, ty, tz;
    private double cx, cy, cz;
    private double ux, uy;
    private double coordonataAxa = 3;
    private int mx, my;
    private boolean startMotion;
    // angle of rotation for the camera direction
float angle=(float) 0.0;
// actual vector representing the camera's direction
float lx=0.0f,lz=-1.0f;
// XZ position of the camera
float x=0.0f,z=5.0f;

    private GL2 gl;
    private GLU glu;

    /**
     * Creates new form MainFrameScene
     *
     * @param canvas
     */
    public MainFrameScene(GLCanvas canvas,FPSAnimator animator) {
        this.canvas = canvas;
        initComponents();
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        this.getContentPane().setPreferredSize(
                new Dimension(screen.width * 4 / 5, screen.height * 4 / 5));
        this.setCanvas();
        canvas.addGLEventListener(new GLEventListener() {
            @Override
            public void init(GLAutoDrawable glad) {
                glInit(glad);
            }

            @Override
            public void dispose(GLAutoDrawable glad) {
                animator.stop();
            }

            @Override
            public void display(GLAutoDrawable glad) {
                glDisplay(glad);
            }

            @Override
            public void reshape(GLAutoDrawable glad, int i, int i1, int i2, int i3) {
                glReshape(glad, i, i1, i2, i3);
            }
        });
        canvas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                motion(e); //To change body of generated methods, choose Tools | Templates.
            }

        });
        this.pack();
    }

    void transform() {
        gl.glRotated(ux, 1, 0, 0);
        gl.glRotated(uy, 0, 1, 0);
        gl.glTranslated(tx, ty, tz);
    }

    private void motion(MouseEvent e) {
        int x = e.getX(), y = e.getY();
        if (!startMotion) {
            startMotion = true;
            mx = x;
            my = y;
        } else {
            if (mx < x) {
                uy += 1;
            } else if (mx > x) {
                uy -= 1;
            }
            if (my < y) {
                ux += 1;
            } else if (my > y) {
                ux -= 1;
            }
            mx = x;
            my = y;
        }
    }

    private void glReshape(GLAutoDrawable glad, int x, int y, int w, int h) {
        double asp = (double) w / h;
        gl.glViewport(x, y, w, h);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(fov, asp, zMin, zMax);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
    }

    private void glDisplay(GLAutoDrawable glad) {
        
        /*gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
        gl.glLoadIdentity();
        glu.gluLookAt(cx, cy, cz, 0, 0, 0, 0, 1, 0);
        transform();
        desen();
        
        gl.glFlush();
        */
        // Clear Color and Depth Buffers
	gl.glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        gl.glColor3f(1.0f, 1.0f, 1.0f);

// Draw Body
	gl.glTranslatef(0.0f ,0.75f, 0.0f);
	glut.glutSolidSphere(0.75f,20,20);

// Draw Head
	gl.glTranslatef(0.0f, 1.0f, 0.0f);
	glut.glutSolidSphere(0.25f,20,20);

        desen();
	// Reset transformations
	/*gl.glLoadIdentity();
	// Set the camera
	glu.gluLookAt(	0.0f, 0.0f, 10.0f,
			0.0f, 0.0f,  0.0f,
			0.0f, 1.0f,  0.0f);

	gl.glRotatef((float) fov, 0.0f, 1.0f, 0.0f);

	gl.glBegin(GL_TRIANGLES);
		gl.glVertex3f(-2.0f,-2.0f, 0.0f);
		gl.glVertex3f(2.0f, 0.0f, (float) 0.0);
		gl.glVertex3f(0.0f, 2.0f, (float) 0.0);
	gl.glEnd();

	fov+=0.1f;

	gl.glFlush();
        */
    }

    private void glInit(GLAutoDrawable glad) {
        initParameters();
        gl = canvas.getContext().getGL().getGL2();
        glu = GLU.createGLU();
    }

    private void initParameters() {
        fov = 70;
        zMin = 2;
        zMax = 20;
        tx = ty = tz = ux = uy = 0;
        cx = cy = 0;
        cz = 5;
    }

    private void setCanvas() {
        this.getContentPane().add(canvas, BorderLayout.CENTER);
    }

    void desen() {
        
gl.glColor3f(1.0f, 1.0f, 1.0f);

// Draw Body
	gl.glTranslatef(0.0f ,0.75f, 0.0f);
	glut.glutSolidSphere(0.75f,20,20);

// Draw Head
	gl.glTranslatef(0.0f, 1.0f, 0.0f);
	glut.glutSolidSphere(0.25f,20,20);

// Draw Eyes
	gl.glPushMatrix();
	gl.glColor3f(0.0f,0.0f,0.0f);
	gl.glTranslatef(0.05f, 0.10f, 0.18f);
	glut.glutSolidSphere(0.05f,10,10);
	gl.glTranslatef(-0.1f, 0.0f, 0.0f);
	glut.glutSolidSphere(0.05f,10,10);
	gl.glPopMatrix();

// Draw Nose
	gl.glColor3f(1.0f, 0.5f , 0.5f);
	glut.glutSolidCone(0.08f,0.5f,10,2);
	/*gl.glColor3f(1.0f, 1.0f, 1.0f);

// Draw Body
	gl.glTranslatef(0.0f ,0.75f, 0.0f);
	//glutSolidSphere(0.75f,20,20);

// Draw Head
	gl.glTranslatef(0.0f, 1.0f, 0.0f);
	//gl.glutSolidSphere(0.25f,20,20);

// Draw Eyes
	gl.glPushMatrix();
	gl.glColor3f(0.0f,0.0f,0.0f);
	gl.glTranslatef(0.05f, 0.10f, 0.18f);
	//glutSolidSphere(0.05f,10,10);
	//glTranslatef(-0.1f, 0.0f, 0.0f);
	//glutSolidSphere(0.05f,10,10);
	gl.glPopMatrix();

// Draw Nose
	gl.glColor3f(1.0f, 0.5f , 0.5f);
	//gl.glutSolidCone(0.08f,0.5f,10,2);

        /*gl.glBegin(GL2.GL_LINES);
        gl.glColor3d(1, 0, 0);
        gl.glVertex3d(-coordonataAxa, 0, 0);
        gl.glVertex3d(coordonataAxa, 0, 0);
        gl.glColor3d(0, 1, 0);
        gl.glVertex3d(0, -coordonataAxa, 0);
        gl.glVertex3d(0, coordonataAxa, 0);
        gl.glColor3d(0, 0, 1);
        gl.glVertex3d(0, 0, -coordonataAxa);
        gl.glVertex3d(0, 0, coordonataAxa);
        gl.glEnd();
        */
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        GLCanvas canvas = new GLCanvas();
        FPSAnimator animator = new FPSAnimator(canvas, 60);
        animator.start();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrameScene(canvas,animator).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
