/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seminar.seminar1.g1081;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 *
 * @author stud
 */
public class FXMLDocumentController implements Initializable {
    
    private Stage myStage;
    
    @FXML
    private Button bScatterplot;
    @FXML
    private Button bLine;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        Scene scena = myStage.getScene();
        BorderPane radacina = (BorderPane) scena.getRoot();
        int n = 30;
        double[] x=new double[n],y=new double[n];
        String[] et = new String[n];
        for(int i=0;i<n;i++){
            x[i] = Math.random()*n;
            y[i] = Math.random()*1000;
            et[i] = "Obiect"+(i+1);
        }
        radacina.setCenter(new Scatterplot(x, y, et));
    }

    @FXML
    private void handleLine(ActionEvent evt){
        Scene scena = myStage.getScene();
        BorderPane radacina = (BorderPane) scena.getRoot();
        int n = 30;
        double[] x=new double[n],y=new double[n];
        String[] et = new String[n];
        for(int i=0;i<n;i++){
            x[i] = Math.random()*n;
            y[i] = Math.random()*40;
            et[i] = "Obiect"+(i+1);
        }
        radacina.setCenter(new Line(et, x,y));
        
    }
    public void setMyStage(Stage myStage) {
        this.myStage = myStage;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
