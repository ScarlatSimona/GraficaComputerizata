/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seminar.seminar1.g1081;

import com.sun.javafx.charts.Legend;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Tooltip;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author stud
 */
public class Scatterplot extends ScatterChart<Number, Number>{
    
    public Scatterplot(double[] x, double[] y,String[] et) {
        super(new NumberAxis(), new NumberAxis());
        XYChart.Series<Number,Number> serie=new XYChart.Series<>();
        for(int i=0;i<x.length;i++){
            XYChart.Data<Number,Number> v = new XYChart.Data<>(x[i], y[i]);
            Rectangle formaPunct = new Rectangle(15, 15);
            formaPunct.setFill(Color.RED);
            v.setNode(formaPunct);
            Tooltip.install(v.getNode(), new Tooltip(et[i]));
            serie.getData().add(v);
        }
        serie.setName("Numele seriei");
        this.getData().add(serie);
        this.setTitle("Exemplu Scatterplot");
        this.getXAxis().setLabel("X");
        this.getYAxis().setLabel("Y");
        Legend legenda = (Legend)this.getLegend();
        Legend.LegendItem item=legenda.getItems().get(0);
        Rectangle fLeg=new Rectangle(20, 20);
        fLeg.setFill(Color.RED);
        item.setSymbol(fLeg);
    }
    
}