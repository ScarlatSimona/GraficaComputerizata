/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seminar.seminar1.g1081;

import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

/**
 *
 * @author stud
 */
public final class Line extends LineChart<String, Number> {

    public Line(String[] et, double[]... x) {
        super(new CategoryAxis(), new NumberAxis());
        int n = x.length,j=0;
        for (double[] y : x) {
            LineChart.Series<String, Number> serie = new XYChart.Series<>();
            for (int i = 0; i < et.length; i++) {
                serie.getData().add(new XYChart.Data<>(et[i], y[i]));
            }
            serie.setName("Serie"+(j++));
            this.getData().add(serie);
        }
    }

}