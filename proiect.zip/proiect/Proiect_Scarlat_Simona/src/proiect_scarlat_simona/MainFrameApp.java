/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proiect_scarlat_simona;

import com.jogamp.opengl.util.FPSAnimator;
import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.TextureIO;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.nio.DoubleBuffer;
import java.nio.FloatBuffer;
import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.awt.GLCanvas;
import javax.media.opengl.glu.GLU;
import javax.media.opengl.glu.GLUquadric;
import javax.swing.JOptionPane;

/**
 *
 * @author simonascarlat
 */
public class MainFrameApp extends javax.swing.JFrame{
    
    private final GLCanvas canvas ;
    
    
    private double fov, zMin, zMax;
    private double transitionX, transitionY, tranzitionZ;
    private double cameraX, cameraY, cameraZ;
    private double ux, uy;
    private final double coord = 3;
    private final double distance = 2.8;

    private int motionX, motionY;
    private boolean startMotion;

    private GLUquadric cylinder, circle;
    
    private GL2 gl;
    private GLU glu;
    
    private int[] indexesTextures;
    private int snowmanBody=0, snowmanHead=0;
    
     private final double[][][] points = {
        {{-distance*2,distance, -distance*2 }, {0,distance, -distance*2  }, {distance*2,distance, -distance*2}},
        {{-distance*2,distance,  distance   }, {0,distance,  distance    }, {distance*2,distance,  distance  }},
        {{-distance*2,distance,  distance*2 }, {0,distance,  distance*2  }, {distance*2,distance,  distance*2}}
    };
    private final double[][][] controlPoints = {
        {{0, 0}, {1, 0}},
        {{0, 1}, {1, 1}}
    };

    private double[] pct;
    private int surface;
    
    
    public MainFrameApp(GLCanvas canvas, FPSAnimator animator)
    {
        //BEGIN <<pregatire suprafata de desenare>>
        this.canvas = canvas;
        this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.setPreferredSize(getWindowSize());
        this.setCanvas();
        //END <<pregatire suprafata de desenare>>
        this.pack();
        
       canvas.addGLEventListener(new GLEventListener() {
            @Override
            public void init(GLAutoDrawable glad) {
                glInitialization(glad);
            }

            @Override
            public void dispose(GLAutoDrawable glad) {
                animator.stop();
            }

            @Override
            public void display(GLAutoDrawable glad) {
                glDisplay(glad);
            }

            @Override
            public void reshape(GLAutoDrawable glad, int i, int i1, int i2, int i3) {
                glReshape(glad, i, i1, i2, i3);
            }
        });
       
       canvas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                motion(e);
            }
       });
       
       canvas.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                onKeyPressed(e);
            }
           
           
       });
        
     
    }
    
    
    public void onKeyPressed(KeyEvent event)
    {
        if (event.isControlDown()) {
            switch (event.getKeyCode()) {
                case KeyEvent.VK_RIGHT:
                    cameraX += 0.2;
                    break;
                case KeyEvent.VK_LEFT:
                    cameraX -= 0.2;
                    break;
                case KeyEvent.VK_UP:
                    cameraY += 0.2;
                    break;
                case KeyEvent.VK_DOWN:
                    cameraY -= 0.2;
                    break;
                case KeyEvent.VK_PAGE_DOWN:
                    cameraZ -= 0.2;
                    break;
                case KeyEvent.VK_PAGE_UP:
                    cameraZ += 0.2;
                    break;
            }
        } else {
            switch (event.getKeyCode()) {
                case KeyEvent.VK_ESCAPE:
                    initializationParameters();
                    break;
                case KeyEvent.VK_RIGHT:
                    transitionX += 0.2;
                    break;
                case KeyEvent.VK_LEFT:
                    transitionX -= 0.2;
                    break;
                case KeyEvent.VK_UP:
                    transitionY += 0.2;
                    break;
                case KeyEvent.VK_DOWN:
                    transitionY -= 0.2;
                    break;
                case KeyEvent.VK_PAGE_DOWN:
                    tranzitionZ -= 0.2;
                    break;
                case KeyEvent.VK_PAGE_UP:
                    tranzitionZ += 0.2;
                    break;
            }
        }
    }
    
    
    public void setCanvas()
    {
        this.getContentPane().add(canvas,BorderLayout.CENTER);
    }
    
    public Dimension getWindowSize()
    {
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        return new Dimension(screen.width * 4/5, screen.height * 4/5);
    }
    
    public void initializationParameters()
    {
        fov = 75;
        zMin = 2;
        zMax = 20;
        transitionX = transitionY = tranzitionZ = ux = uy = 0;
        cameraX = cameraY = 0;
        cameraZ = 5;
    }
    
     private int[] loadTextures(String[] files) {
        int n = files.length;
        int[] listOfCodes = new int[n];
        try {
            for (int i = 0; i < n; i++) {
                Texture textura = TextureIO.newTexture(new File(files[i]), true);
                listOfCodes[i] = textura.getTextureObject(gl);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex);
        }
        return listOfCodes;
    }

     
    public void setTextures()
    {
         indexesTextures = loadTextures(new String[]{
            "snow.jpg","heat.jpg","surface.jpg"
        });
    }
    
    public void glInitialization(GLAutoDrawable glad)
    {
        canvas.requestFocus();
        gl = canvas.getContext().getGL().getGL2();
        glu = GLU.createGLU();
        gl.glEnable(GL2.GL_DEPTH_TEST);
        
        
        initializationParameters();
        setTextures();
        pct = liniarizare(points);
       
        surface = gl.glGenLists(1);
        if (surface != 0) {
            gl.glNewList(surface, GL2.GL_COMPILE);
            createSnowSurface();
            gl.glEndList();
        }
        lighting();
        cylinder= glu.gluNewQuadric();
        circle = glu.gluNewQuadric();
        
    }
    
    public void glDisplay(GLAutoDrawable glad)
    {
           
       gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
       //background color
       gl.glClearColor (0.8f,0.8f,0.8f,1.0f);
       gl.glLoadIdentity();
       glu.gluLookAt(cameraX, cameraY, cameraZ, 0, 0, 0, 0, 1, 0);
       transform();
       drawAxis(GL2.GL_RENDER);
       
       snowmanBody= gl.glGenLists(1);
       snowmanHead = gl.glGenLists(1);
        if (snowmanBody != 0 && snowmanHead != 0) {
          gl.glNewList(snowmanBody, GL2.GL_COMPILE_AND_EXECUTE);
          gl.glNewList(snowmanHead, GL2.GL_COMPILE_AND_EXECUTE);
          drawSnowmanBody();
          drawHead();
          gl.glEndList();
        }
       //desenare om de zapada folosind liste 
      gl.glCallList(snowmanBody);
      gl.glCallList(snowmanHead);
      gl.glCallList(surface);
      drawSnowmanHeat();
    }
    
    public void drawAxis(int mod)
    {      
        gl.glBegin(GL2.GL_LINES);
        gl.glColor3d(0, 0, 0);
        gl.glVertex3d(-coord, 0, 0);
        gl.glVertex3d(coord, 0, 0);
        gl.glColor3d(1, 0, 0);
        gl.glVertex3d(0, -coord, 0);
        gl.glVertex3d(0, coord, 0);
        gl.glColor3d(0, 0, 1);
        gl.glVertex3d(0, 0, -coord);
        gl.glVertex3d(0, 0, coord);
        gl.glEnd();
        
    }
    
    public void transform()
    {
        gl.glRotated(ux, 1, 0, 0);
        gl.glRotated(uy, 0, 1, 0);
        gl.glTranslated(transitionX, transitionY, tranzitionZ);
    }
    
     private void createSnowSurface() {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glPushMatrix();
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glEnable(GL2.GL_MAP2_TEXTURE_COORD_2);
        gl.glTexEnvf(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_DECAL);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, indexesTextures[2]);
        gl.glEnable(GL2.GL_MAP2_VERTEX_3);
        gl.glMap2d(GL2.GL_MAP2_VERTEX_3, 0, 1, 3, 3, 0, 1, 9, 3, DoubleBuffer.wrap(pct));
        gl.glRotated(-90, 0, 0, 0);
        gl.glMapGrid2d(20, 0, 1, 20, 0, 1);
        gl.glMap2d(GL2.GL_MAP2_TEXTURE_COORD_2, 0, 1, 2, 2, 0, 1, 4, 2,
                DoubleBuffer.wrap(liniarizare(controlPoints)));
        gl.glEvalMesh2(GL2.GL_FILL, 0, 20, 0, 20);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPopMatrix();
        gl.glDisable(GL2.GL_LIGHTING);
    }
    
     private void glReshape(GLAutoDrawable glad, int x, int y, int w, int h) {
        double asp = (double) w / h;
        gl.glViewport(x, y, w, h);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(fov, asp, zMin, zMax);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
    }
     
     
     public void motion(MouseEvent event)
     {
         int x = event.getX(), y = event.getY();
        if (!startMotion) {
            startMotion = true;
            motionX = x;
            motionY = y;
        } else {
            if (motionX < x) {
                uy += 1;
            } else if (motionY > x) {
                uy -= 1;
            }
            if (motionY < y) {
                ux += 1;
            } else if (motionY > y) {
                ux -= 1;
            }
            motionX = x;
            motionY = y;
        }
     }
     
    private double[] liniarizare(double[][][] x) {
        int n = x.length, m = x[0].length;
        int r = x[0][0].length;
        double[] p = new double[n * m * r];
        for (int i = 0, k = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                for (int l = 0; l < r; l++, k++) {
                    p[k] = x[i][j][l];
                }
            }
        }
        return p;
    }
     
     private void drawHead()
     {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DIFFUSE, FloatBuffer.wrap(new float[]{1.0f, 1.0f, 1.0f}));

        gl.glPushMatrix();
        gl.glTranslated(0, 0, 0);
        gl.glRotated(-90, 1, 0, 0);

        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, indexesTextures[0]);
        
        //snowman head
        glu.gluSphere(circle, 0.5, 8, 8);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPushMatrix();
        gl.glTranslated(0, 0, 1);
        //glu.gluDisk(disc, 2, 0, 30, 30);
        gl.glPopMatrix();
        gl.glPopMatrix();
        gl.glDisable(GL2.GL_LIGHTING);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        
        //snowman eyes
        gl.glPushMatrix();
        gl.glColor3f(0.0f,0.0f,0.0f);
        gl.glTranslated(-0.1, -0.4, 0.3);
        glu.gluSphere(circle,0.04f,10,10);
        gl.glTranslated(0.2, -0.0, 0.02);
        glu.gluSphere(circle,0.04f,10,10);
  
        //snowman nose
        gl.glColor3f(1.0f, 0.5f , 0.0f);
        gl.glTranslated(-0.1, -0.1, -0.25);
        gl.glRotated(85, 1, 0, 0);
        glu.gluCylinder(cylinder, 0.1, 0, 0.2, 10, 10); 
        gl.glPopMatrix();
     }
     
     
    private void drawSnowmanHeat() {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DISCRETE_AMD, FloatBuffer.wrap(new float[]{0.8f, 0.8f, 0.8f}));
        gl.glPushMatrix();
        gl.glTranslated(0, 0, 0);
        gl.glRotated(-30, 1, 0, 0);

        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, indexesTextures[1]);
        glu.gluQuadricTexture(cylinder, true);
        glu.gluCylinder(cylinder, 0.5, 0.5, 1, 5, 5);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPushMatrix();
       
        gl.glPopMatrix();
        gl.glPopMatrix();
        gl.glDisable(GL2.GL_LIGHTING);
        gl.glDisable(GL2.GL_TEXTURE_2D);
    }
    
           
    private void drawSnowmanBody() {
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glMaterialfv(GL2.GL_FRONT_AND_BACK, GL2.GL_DIFFUSE, FloatBuffer.wrap(new float[]{1.0f, 1.0f, 1.0f}));

        //bulgare bottom
        gl.glPushMatrix();
        gl.glTranslated(0, 0, -2);
        gl.glRotated(-90, 1, 0, 0);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, indexesTextures[0]);
        glu.gluQuadricTexture(circle, true);
        glu.gluSphere(circle, 1, 10, 10);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPushMatrix();
        gl.glTranslated(0, 0, 1);
        gl.glPopMatrix();
        gl.glPopMatrix();
        
        //bulgare middle
        gl.glPushMatrix();
        gl.glTranslated(0, 0, -1);
        gl.glRotated(-90, 1, 0, 0);
        gl.glEnable(GL2.GL_TEXTURE_2D);
        gl.glBindTexture(GL2.GL_TEXTURE_2D, indexesTextures[0]);
        glu.gluSphere(circle, 0.8, 9, 9);
        gl.glDisable(GL2.GL_TEXTURE_2D);
        gl.glPushMatrix();
        gl.glTranslated(0, 0, 1);
        gl.glPopMatrix();
        gl.glPopMatrix();
        gl.glDisable(GL2.GL_LIGHTING);
        gl.glDisable(GL2.GL_TEXTURE_2D);
    
    }
     
    
    private void lighting() {
        gl.glEnable(GL2.GL_AUTO_NORMAL);
        gl.glEnable(GL2.GL_LIGHT1);
        gl.glLightfv(GL2.GL_LIGHT1, GL2.GL_POSITION, FloatBuffer.wrap(new float[]{0, 0, 5, 0}));
          
    }
     
     
     
    public static void main(String[] args)
    {
        GLCanvas canvas = new GLCanvas();
        FPSAnimator animator = new FPSAnimator(canvas, 60);
        animator.start();
        
        MainFrameApp appScene = new MainFrameApp(canvas, animator);
        appScene.setVisible(true);
    }
}
